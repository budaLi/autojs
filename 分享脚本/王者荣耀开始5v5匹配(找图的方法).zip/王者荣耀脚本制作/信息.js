console.show();
var dir = "./img"; 
var jsFiles = files.listDir(dir, function(name){ 
return name.endsWith(".jpg") && files.isFile(files.join(dir, name)); 
}); 
log(jsFiles.join("\n"));