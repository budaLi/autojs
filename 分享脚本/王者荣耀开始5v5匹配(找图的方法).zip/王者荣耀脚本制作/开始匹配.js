auto();//无障碍权限
setScreenMetrics(1080, 1920);//设置所适合的屏幕宽高
requestScreenCapture(true); //请求截图
//请求截图 

//console.show();

function 截图() {
while (true) {
if (图=captureScreen()) {
return 图;
break;
}
}
} //获取截图，返回图片对象
 
function save(path,txt){
try{
//以写入模式打开SD卡根目录文件 B
var file = open(path, "w")
//写入aaaa
file.write(txt);
//关闭文件
file.close();
return true;
}catch(e){return false;}
}
var path="/sdcard/王者荣耀脚本制作/img";
var tuzu=[
[662,810,594,150,"img_开始游戏.jpg"],
[1466,44,234,240,"img_X.jpg"]
];
var tuzu1=[
[254,694,696,186,"img_对战模式.jpg"],
[74,664,750,192,"img_实战对抗.jpg"],
[110,406,606,534,"img_5V5.jpg"],
[772,812,570,168,"img_开始匹配.jpg"],
[652,698,600,174,"img_进入游戏.jpg"]
];


//var str=new Array;
//str.push([0,0,0,0]);

launchApp("王者荣耀");
sleep(10000);

var kg=false;
for(var i=0;i<tuzu.length;i++){
sleep(1500);
//threads.start(function (){
var IMG=截图();
var img=images.read(files.join("./img",tuzu[i][4])); 
var X=Math.round(img.getWidth()/2),Y=Math.round(img.getHeight()/2); 
var point=findImage(IMG,img,{
region: [tuzu[i][0],tuzu[i][1],tuzu[i][2],tuzu[i][3]],
threshold: 0.8 
}); 
if(point){
var x=parseInt(point.x)+X,y=parseInt(point.y)+Y;
log(tuzu[i][4]+"\nX: " +x+"Y: "+y);
click(x,y); 
kg=true;
i--;
}else{
if(!kg){i--}else{kg=false};
};
//});
}

//save("./abc.txt",str.join(","));



sleep(1000);

var kg=false;
for(var i=0;i<tuzu1.length;i++){
sleep(1500);
//threads.start(function (){
var IMG=截图();
var img=images.read(files.join("./img",tuzu1[i][4])); 
var X=Math.round(img.getWidth()/2),Y=Math.round(img.getHeight()/2); 
var point=findImage(IMG,img,{
region: [tuzu1[i][0],tuzu1[i][1],tuzu1[i][2],tuzu1[i][3]],
threshold: 0.8
}); 
if(point){
var x=parseInt(point.x)+X,y=parseInt(point.y)+Y;
log(tuzu1[i][4]+"\nX: " +x+"Y: "+y);
click(x,y); 
kg=true;
i--;
}
else{
if(!kg){i--}else{kg=false};
};
//});
}




//save("./abc.txt",str.join(","));
sleep(100);
toast("停止");
exit();










