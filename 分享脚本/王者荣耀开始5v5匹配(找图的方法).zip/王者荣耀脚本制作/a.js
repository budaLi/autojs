"ui";
 ui.layout(
    <vertical>
       <text alpha="0.5" id="text" w="*" />
       <webview w="*" h="*" size="6" id="webview" margin="0 1"/>

    </vertical>
);
   
var url="http://m.x81zw.com/book/0/248/3891680.html";
ui.webview.loadUrl(url);

ui.run(()=>{
var a//=ui.webview.getText();
toast(a)
});

setTimeout(()=>{  }, 10000);
//记录按键被按下时的触摸坐标
var x,y,sx,sy,windowX,windowY,time;

ui.text.setOnTouchListener(function(view, event){
switch(event.getAction()){
case event.ACTION_DOWN:
x = event.getRawX();
y = event.getRawY();
windowX = window.getX();
windowY = window.getY();
//time=new Date;
return true;

case event.ACTION_MOVE:
sx=event.getRawX() - x;       
sy=event.getRawY() - y;
//window.setPosition(windowX +sx,windowY+sy);
return true;

case event.ACTION_UP:
//if(new Date-time>1000){exit();}
//window.setPosition(windowX +sx,windowY+sy);
return true;
}
return true;
});
