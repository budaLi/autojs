//"ui";
//console.show();
//window.setAdjustEnabled(true);
importClass(android.graphics.Paint);
importClass(android.graphics.Canvas);
importClass(android.graphics.Bitmap);

//路径提取
function dir_abcd(a,b,c,d){
var A=a.split(b);
var K=new Array;
var kg=false;
for(var i=0;i<A.length;i++){
if(i==c||i==A.length+c){kg=true};
if(kg){K.push(A[i])};
if(i==d||i==A.length+d){kg=false};
}
return K.join(b);
}


//存画
function saveimg(path,bitmap){
try{
var file = new java.io.File(path);          
var fileOutput = new java.io.FileOutputStream(file);
bitmap.compress(Bitmap.CompressFormat.PNG,100,fileOutput); 
return true;
}catch(e){log(e) ;return false;}
}

 var tuzu=[
[662,810,594,150,"img_对战模式.jpg"],
[1466,44,234,240,"img_实战对抗.jpg"],
[254,694,696,186,"img_对战模式.jpg"],
[74,664,750,192,"img_实战对抗.jpg"],
[158,406,606,534,"img_5V5.jpg"],
[772,812,570,168,"img_开始匹配.jpg"],
[652,698,600,174,"img_进入游戏.jpg"]
];

    var bitmap = Bitmap.createBitmap(1920, 1080, Bitmap.Config.ARGB_8888);

    var canvas = new Canvas(bitmap);
    canvas.drawARGB(31,31,0,0);
    var paint = new Paint();

var se=255;
paint.setStrokeWidth(5); //边缘宽度
for(var i=0;i<tuzu.length;i++){
 paint.setARGB(255, se, 0, 0); //白色画笔
canvas.drawLine(tuzu[i][0],tuzu[i][1],tuzu[i][0]+tuzu[i][2],tuzu[i][1], paint); //绘制直线→
canvas.drawLine(tuzu[i][0],tuzu[i][1],tuzu[i][0],tuzu[i][1]+tuzu[i][3], paint); //绘制直线↓
//canvas.drawLine(x,y,x,y, paint); //绘制直线
//canvas.drawLine(x,y,x,y, paint); //绘制直线
se-=36;
log(tuzu[i][0],tuzu[i][1],tuzu[i][0]+tuzu[i][2],tuzu[i][1])
}

    paint.setARGB(255, 128, 0, 0); //白色画笔
    paint.setStyle(Paint.Style.FILL); //空心样式  
    //canvas.drawCircle(960, 540, 10, paint); //绘制圆

canvas.drawLine(2,2,1918,2, paint); //绘制直线
canvas.drawLine(2,2,2,1078, paint); //绘制直线
canvas.drawLine(1918,1078,2,1078, paint); //绘制直线
canvas.drawLine(1918,1078,1918,2, paint); //绘制直线
 
     
      
canvas.save(Canvas.ALL_SAVE_FLAG);
canvas.restore();


ui.run(function() {
      //ui.img.setImageBitmap(bitmap);
    });
// var path="/sdcard/王者荣耀脚本制作/图片/画出.png";
 var path=files.join("/sdcard",files.join(dir_abcd(files.cwd(),"/",4,-1),"/图片/画出.png"));

if(saveimg(path,bitmap)){log("已保存");}else{log("2")};
 
   
   

   
   
   
   
   
    
        /*
    paint.setARGB(255,0,0,0);//白色画笔
    paint.setStyle(Paint.Style.FILL);//空心样式  
    canvas.drawCircle(540,540,510, paint);//绘制圆
    */
/*
    paint.setARGB(255, 255, 255, 255); //白色画笔
    paint.setStyle(Paint.Style.STROKE); //空心样式  
    paint.setStrokeWidth(5); //边缘宽度  
    canvas.drawCircle(540, 540, 500, paint); //绘制圆
*/


